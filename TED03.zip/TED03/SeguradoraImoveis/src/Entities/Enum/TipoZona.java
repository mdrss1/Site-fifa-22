package Entities.Enum;

public enum TipoZona {
    SUBURBANA,
    RURAL,
    URBANA;
}