package Entities.Enum;

public enum TipoResidencia {
    CASA,
    PREDIO;
}