package Entities.Enum;

public enum TipoPessoa {
    PF,
    PJ;
    //PF: PESSOA FISICA/ PJ:PESSOA JURIDICA.
}