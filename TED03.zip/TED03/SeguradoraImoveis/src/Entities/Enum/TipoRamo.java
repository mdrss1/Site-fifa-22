package Entities.Enum;

public enum TipoRamo {
    LOJA,
    FÁBRICA,
    AGROPECUARIA;
}