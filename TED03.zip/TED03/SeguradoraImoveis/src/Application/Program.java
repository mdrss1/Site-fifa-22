package Application;

import Entities.Enum.TipoPessoa;
import Entities.Enum.TipoRamo;

public class Program {
    public static void main(String[] args) {
        UI.exibeMenu();
    }
}